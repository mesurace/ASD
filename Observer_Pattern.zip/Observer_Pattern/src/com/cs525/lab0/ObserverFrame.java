package com.cs525.lab0;

public interface ObserverFrame {
	public void setCount(int cnt);
}
